<?php 
/******** CURL method for Hoku API *********/ 		
$hku_params=array(	
        "emailid"=>$email,
        "phonenumber"=>$phone,
        "projectname"=>"PBEL City",
        "name"=>$full_name,
        "key"=>"5F9EE6B0B71B4DC281EE198B38FB9624",
        "source"=>"Digital",
        "primarysource"=>$leadutmsource,
        "secondarysource"=>$leadutmmedium,
        "tertiarysource"=>$leadutmcampaign,
        "sourceurl"=>$form_page
);

$hku_fields = $hku_params;
$hku_postvars = '';
  foreach($hku_fields as $key=>$value) {
    $hku_postvars .= $key . "=" . $value . "&";
  }   
$ch1 = curl_init();
curl_setopt($ch1, CURLOPT_URL,"https://sales.indis.work/incorversion4/createExternalLeads");
curl_setopt($ch1, CURLOPT_POST, 1);
curl_setopt($ch1, CURLOPT_POSTFIELDS,$hku_postvars);
curl_setopt($ch1, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch1, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, 0);
$server_output1 = curl_exec ($ch1);
curl_close ($ch1);
error_log("HOKU CRM Response API - 2019-indis-tower-N-launch".$server_output1."-->".$email);

