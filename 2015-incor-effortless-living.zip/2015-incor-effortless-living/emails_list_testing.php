<?php

$from = 'ask@indis.co.in';
$from_name = 'PBEL City';
$to = 'ask@indis.co.in';
$to_name = 'PBEL City';
$cc_emails = array(
// "neha.purohit@deepredink.com",
// "venkat@deepredink.com",
);
$bcc_emails = array(

);



