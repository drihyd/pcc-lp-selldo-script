$(document).ready(function(){
    $("body").scrollspy({target: "#top-navigation", offset:150});
});

// code for smooth scrolling
$('a').click(function(){
    $('html, body').animate({
        scrollTop: $( $.attr(this, '*href') ).offset().top - 80
    }, 500);
    return false;
});


