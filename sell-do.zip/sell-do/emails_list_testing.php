<?php

$from = 'test@deepredink.com';
$from_name = 'Test';

$to = 'test@deepredink.com';
$to_name = 'Test';

$cc_emails = array(
	'venkat@deepredink.com',
	'rajkumar@deepredink.com',
	'balaraju@deepredink.com',
);

$bcc_emails = array(
	//'balara@deepredink.com' => 'Test',
);
